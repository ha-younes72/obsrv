export default data = [
  { name: 'ios-airplane' },
  { name: 'ios-american-football' },
  { name: 'ios-baseball' },
  { name: 'ios-basketball' },
  { name: 'ios-bicycle' },
  { name: 'ios-body' },
  { name: 'ios-brush' },
  { name: 'ios-bug' },
  { name: 'ios-cart' },
  { name: 'ios-car' },
  { name: 'ios-camera' },
  { name: 'ios-cloudy-night' },
  { name: 'ios-color-palette' },
  { name: 'ios-easel' }
]
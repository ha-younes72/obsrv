const colors = {
  primaryBackGround: "#F2F1F0",
  primary: "#009BA1",
  //primary: "#00BFFF",//'#0b377f',//'#D81B60'
  primaryLight: '#4083ef',
  textColor: 'white',
  black: '#1a1917',
  gray: '#DEDEDE' ,//'#DEDEDE',
  background1: '#B721FF',
  background2: '#21D4FD'
}

const fonts = {
  primary: 'Lobster'
}

export {
  colors,
  fonts
}

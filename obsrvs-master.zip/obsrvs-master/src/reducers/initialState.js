
export default {
	app: {
		observations: [],
		newObservations: [],
		currentIndex: -1,
		wantToAddPhoto: false

	},
	auth: {
		user: {},
		token: '',
		message: '',
		status: false
	}
};


export default {
	app: {
		observations: [],
		newObservations: [],
		currentIndex: -1,
		wantToAddPhoto: false,
		tempObservation: {}

	},
	auth: {
		user: {},
		token: '',
		message: '',
		status: false
	}
};

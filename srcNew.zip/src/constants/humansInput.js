export default data = [
  {
    id: 1,
    name: "Jelly Fish"
  },
  {
    id: 2,
    name: "Whale"
  },
  {
    id: 3,
    name: "Dog"
  },
  {
    id: 4,
    name: "Wolf"
  },
  {
    id: 5,
    name: "Sheep"
  },
  {
    id: 6,
    name: "Donkey"
  },
  {
    id: 7,
    name: "Girrafe"
  },
  {
    id: 8,
    name: "Cow"
  },
  {
    id: 9,
    name: "Calf"
  },
  {
    id: 10,
    name: "Cat"
  },
  {
    id: 11,
    name: "Lion"
  },
  {
    id: 12,
    name: "Tiger"
  }
]
//import Config from 'react-native-config';

export const API_URL = 'http://35.183.161.65:3005/';//'http://10.20.3.147:3005/';
export const API_KEY = ''//Config.API_KEY;

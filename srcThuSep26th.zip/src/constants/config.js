export const USER_KEY = 'USER_KEY'

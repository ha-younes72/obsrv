//import Config from 'react-native-config';

export const API_URL = 'https://eoceans.app:3005/';//'http://35.183.161.65:3005/'; //'http://35.226.33.134:3005/';
export const API_KEY = ''//Config.API_KEY;
